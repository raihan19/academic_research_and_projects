#include <bits/stdc++.h>

using namespace std;

class R_type{
    void shift();
public:
    string errorMessage="";
    string translated="";
    vector<string> v;
    R_type();
    R_type(vector<string> a);
    void solve();

};



