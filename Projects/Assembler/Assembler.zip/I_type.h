#include <bits/stdc++.h>

using namespace std;

class Itype{
private:
    void memAccess();
    void decision();
public:
    string errorMessage="";
    string translated="";
    vector<string> v;
    Itype();
    Itype(vector<string> a);
    void solve();


};


